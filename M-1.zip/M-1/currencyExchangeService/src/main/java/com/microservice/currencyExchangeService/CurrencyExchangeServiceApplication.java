package com.microservice.currencyExchangeService;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

import com.microservice.currencyExchangeService.model.ExchangeValueModel;
import com.microservice.currencyExchangeService.repository.ExchangeServiceRepository;

@SpringBootApplication
@EnableDiscoveryClient
public class CurrencyExchangeServiceApplication {

	@Autowired
	ExchangeServiceRepository exchangeRepository;

	@PostConstruct
	public void initUsers() {
		List<ExchangeValueModel> users = Stream.of(new ExchangeValueModel(10001L,"USD","INR", new BigDecimal("70")),
				new ExchangeValueModel(10002L,"EUD","INR",new BigDecimal(110)),
				new ExchangeValueModel(10003L,"AUD","INR",new BigDecimal(250))).collect(Collectors.toList());
				exchangeRepository.saveAll(users);
	} 
	
	
	
	public static void main(String[] args) {
		SpringApplication.run(CurrencyExchangeServiceApplication.class, args);
	}

}
