package com.microservice.currencyExchangeService.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.microservice.currencyExchangeService.model.ExchangeValueModel;

@Repository
public interface ExchangeServiceRepository extends CrudRepository<ExchangeValueModel, Long> {  
	
	ExchangeValueModel findByFromAndTo(String from,String to);

}
