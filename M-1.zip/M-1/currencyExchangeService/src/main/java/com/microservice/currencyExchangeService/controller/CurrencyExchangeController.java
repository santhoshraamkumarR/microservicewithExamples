package com.microservice.currencyExchangeService.controller;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.microservice.currencyExchangeService.model.ExchangeValueModel;
import com.microservice.currencyExchangeService.repository.ExchangeServiceRepository;

@RestController
public class CurrencyExchangeController {

 	@Autowired
 	private Environment environment;
 	
 	@Autowired
 	ExchangeServiceRepository exchangeRepository;
	
	@GetMapping("currencyExchange/from/{from}/to/{to}")
	public ExchangeValueModel retriveExchangeValue(@PathVariable String from,@PathVariable String to) {
		//ExchangeValueModel exchangeValueModel = new ExchangeValueModel(1000L, "USD","INR", BigDecimal.valueOf(70));
		ExchangeValueModel exchangeValueModel = exchangeRepository.findByFromAndTo(from, to);
		exchangeValueModel.setPort(Integer.parseInt(environment.getProperty("local.server.port")));
		return  exchangeValueModel;
	}
	
	
}
