package com.microservice.currencyCalculatorService.facade;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.microservice.currencyCalculatorService.model.CalculatedAmount;


//@FeignClient(name="Currency-Exchange-Service",url="http://localhost:8083/")
@FeignClient(name="currency-exchange-service")
@RibbonClient(name="currency-exchange-service")
public interface CurrencyExchangeProxy {
	
	
	@GetMapping("currencyExchange/from/{from}/to/{to}")
	public CalculatedAmount retriveExchangeValue(@PathVariable("from") String from,@PathVariable("to") String to);
	
	
	
}
