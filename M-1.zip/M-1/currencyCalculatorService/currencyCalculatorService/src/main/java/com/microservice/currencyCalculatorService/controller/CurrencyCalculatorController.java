package com.microservice.currencyCalculatorService.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponents.UriTemplateVariables;

import com.microservice.currencyCalculatorService.facade.CurrencyExchangeProxy;
import com.microservice.currencyCalculatorService.model.CalculatedAmount;

@RestController
public class CurrencyCalculatorController {
	
	@Autowired
	CurrencyExchangeProxy currencyExchangeProxy;
	
	@GetMapping("currency-convertor/from/{from}/to/{to}/quantity/{quantity}")
	public CalculatedAmount calculateAmount(@PathVariable String from,@PathVariable String to,@PathVariable BigDecimal quantity) {
		Map<String,String> uriVariables = new HashMap<>(); 
		uriVariables.put("from",from);
		uriVariables.put("to", to);
		ResponseEntity<CalculatedAmount> responseEntity= new RestTemplate().getForEntity("http://localhost:8083/currencyExchange/from/{from}/to/{to}/", CalculatedAmount.class,uriVariables);
		CalculatedAmount calAmt = responseEntity.getBody();
		
		return new CalculatedAmount(calAmt.getId(),calAmt.getFrom(),calAmt.getTo(),calAmt.getConversionMultiple(),
				quantity,quantity.multiply(calAmt.getConversionMultiple()),calAmt.getPort());
	}
	
	
	
	@GetMapping("currency-convertor-feign/from/{from}/to/{to}/quantity/{quantity}")
	public CalculatedAmount calculateAmountFeign(@PathVariable String from,@PathVariable String to,@PathVariable BigDecimal quantity) {
//		Map<String,String> uriVariables = new HashMap<>(); 
//		uriVariables.put("from",from);
//		uriVariables.put("to", to);
//		ResponseEntity<CalculatedAmount> responseEntity= new RestTemplate().getForEntity("http://localhost:8083/currencyExchange/from/{from}/to/{to}/", CalculatedAmount.class,uriVariables);
//		CalculatedAmount calAmt = responseEntity.getBody();
//		
		CalculatedAmount calAmt = currencyExchangeProxy.retriveExchangeValue(from, to);
		return new CalculatedAmount(calAmt.getId(),calAmt.getFrom(),calAmt.getTo(),calAmt.getConversionMultiple(),
				quantity,quantity.multiply(calAmt.getConversionMultiple()),calAmt.getPort());
	}

}
