/*package com.microservice.currencyCalculatorService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CurrencyCalculatorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
*/