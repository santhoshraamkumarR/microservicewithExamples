package com.tecnotab.zuulapiserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NetflixZuulApiGatewayServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
