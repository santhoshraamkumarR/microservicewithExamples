package com.microservice.limitservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LimitserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
